﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    class add : Operating
    {

        public override object Operate(Operand num1, Operand num2)
        {
            object temp;
            if (num1.Num.GetType() == typeof(int))
            {
                temp = (int)num1.Num + (int)num2.Num;
            }
            else
            {
                temp = (string)num1.Num + (string)num2.Num;
            }
            return temp;
        }
    }
}
