﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    class Operand
    {
        private Object num;

        public object Num { get => num; set => num = value; }
    }
}
