﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
   abstract class Operating
    {
        protected Operand num1;
        protected Operand num2;
        public abstract Object Operate(Operand num1, Operand num2);
    }
}
