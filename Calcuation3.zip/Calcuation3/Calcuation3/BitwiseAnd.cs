﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calcuation3
{
    class BitwiseAnd : Operating
    {
        public override object Operate(Operand num1, Operand num2)
        {
            object temp = null;
            if (num1.Num.GetType() == typeof(int) && num2.Num.GetType() == typeof(int))
            {
                temp = (int)num1.Num & (int)num2.Num;
            }
            else
            {
                temp = "输入错误！";
            }
            return temp;
        }
    }
}
