﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calcuation3
{
    class Program
    {
        static void Main(string[] args)
        {
            Operand num1 = new Operand();
            Operand num2 = new Operand();
            Operating operating;
            object sum = null;
            int temp1;
            Console.WriteLine("请输入第一个操作数");
            string temp = Console.ReadLine();
            if (int.TryParse(temp, out temp1))
            {
                num1.Num = temp1;
            }
            else
            {
                num1.Num = temp;
            }
            Console.WriteLine("请输入第二个操作数");
            temp = Console.ReadLine();
            if (int.TryParse(temp, out temp1))
            {
                num2.Num = temp1;
            }
            else
            {
                num2.Num = temp;
            }
            string s;
            Console.WriteLine("请输入操作符：");
            s = Console.ReadLine();
            switch (s)
            {
                case "+":
                    operating = new add();
                    sum = operating.Operate(num1, num2);
                    Console.WriteLine("{0}+{1}={2}", num1.Num, num2.Num, sum);
                    break;
                case "-":
                    operating = new Division();
                    sum = operating.Operate(num1, num2);
                    Console.WriteLine("{0}-{1}={2}", num1.Num, num2.Num, sum);
                    break;
                case "*":
                    operating = new multiplication();
                    sum = operating.Operate(num1, num2);
                    if (sum.GetType() == typeof(int))
                    {
                        Console.WriteLine("{0}*{1}={2}", num1.Num, num2.Num, sum);
                    }
                    else
                        Console.WriteLine(sum);
                    break;
                case "/":
                    operating = new Subtraction();
                    sum = operating.Operate(num1, num2);
                    if (sum.GetType() == typeof(int))
                    {
                        Console.WriteLine("{0}/{1}={2}", num1.Num, num2.Num, sum);
                    }
                    else
                        Console.WriteLine(sum);
                    break;
                case "&":
                        operating = new BitwiseAnd();
                        sum = operating.Operate(num1, num2);
                    if (sum.GetType() == typeof(int))
                    {
                        Console.WriteLine("{0}&{1}={2}", num1.Num, num2.Num, sum);
                    }
                    else
                        Console.WriteLine( sum);
                    break;
                case "%":
                    operating = new Remainder();
                    sum = operating.Operate(num1, num2);
                    if (sum.GetType() == typeof(int))
                    {
                        Console.WriteLine("{0}%{1}={2}", num1.Num, num2.Num, sum);
                    }
                    else
                        Console.WriteLine(sum);
                    break;
            }
            Console.ReadKey();
        }
    }
}
